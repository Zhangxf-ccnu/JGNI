JGNI = function(X, lambda, alpha, model = "Gaussian", weights = "equal", penalize.diagonal = FALSE){

  K = dim(X)[1]
  G = dim(X)[2]
  p = dim(X[[1,1]])[2]
  n = rep(0, G)
  for (g in 1:G){
    n[g] =  dim(X[[1,g]])[1]
  }

  S = matrix(list(), K, G)

  if (model == "Gaussian"){
    for (k in 1:K){
      for (g in 1:G){
        S[[k,g]] = Corr(X[[k,g]], method = "pearson")
      }
    }
  }

  if (model == "nonparanormal"){
    for (k in 1:K){
      for (g in 1:G){
        S[[k,g]] = Corr(X[[k,g]], method = "kendall")
      }
    }
  }

  if (weights=="equal"){
    n = rep(1,G)
  }else if (weights=="sample.size"){
    n = n
  }else{
    n = weights
  }


  result = admm(S, lambda, alpha, n = n, penalize.diagonal = penalize.diagonal)

  result$Omega.bar = matrix(list(), 1, G)
  result$M.bar = matrix(list(), 1, G)
  result$R.bar = result$R.hat[[1]]!=0
  diag(result$R.bar) <- 0
  for (g in 1:G){
    result$Omega.bar[[g]] =  result$Omega.hat[[1,g]]!=0
    diag(result$Omega.bar[[g]]) <- 0
    result$M.bar[[g]] =  (result$Omega.hat[[1,g]]!=0)&(result$R.bar==0)
    diag(result$M.bar[[g]]) <- 0

  }

  result
}
