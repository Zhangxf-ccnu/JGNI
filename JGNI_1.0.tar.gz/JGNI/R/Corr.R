require("Matrix")
require("stats")

Corr <- function(X, method = "pearson"){

  n = dim(X)[1]

  if(method=="pearson"){
    S = (n-1)*cov(X, method = "pearson")/n
  }

  if (method == "kendall"){
    S = cor(X, method = "kendall")
    S = sin(S*pi/2)
    S[is.na(S)] = 0
    diag(S) <- 1
    S = as.matrix(nearPD(S, corr = TRUE)$mat)
  }

  S
}

