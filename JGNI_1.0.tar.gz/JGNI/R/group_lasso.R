group_lasso <- 
  function(A, lambda, penalize.diagonal=FALSE){
    K = length(A)
    normA = A[[1]]*0
    for(k in 1:K){
      normA = normA + (A[[k]])^2
    }
    normA = sqrt(normA)
    
    notshrunk = (normA>lambda)*1
    # reset 0 elements of normA to 1 so we don't get NAs later. 
    normA = normA + (1-notshrunk)
    
    out = A
    for(k in 1:K)
    {
      out[[k]] = A[[k]]*(1-lambda/normA)
      out[[k]] = out[[k]]*notshrunk
      if(!penalize.diagonal){
        diag(out[[k]]) <- diag(A[[k]])
      }
    }
    out
  }

