admm <-
  function(S, lambda, alpha, n = NULL, penalize.diagonal = FALSE, epsilon = 1e-5, maxiter = 500, rho = 0.1,  rho.incr = 1.2, rho.max = 1e10){
    #
    
    K = dim(S)[1]
    G = dim(S)[2]
    p = dim(S[[1,1]])[1]
    
    
    if(is.null(n)){
      n = rep(1, G)
    }
    
    # initialize:    
    Omega = matrix(list(), K, G)
    R = matrix(list(), K, 1)
    M = matrix(list(), K, G)
    Q = matrix(list(), K, G)
    
    for (k in 1:K){  
      R[[k]] = diag(p)
      for (g in 1:G){
        M[[k,g]] = diag(p)
        Omega[[k,g]] = diag(p)
        Q[[k,g]] = matrix(0, p, p)    
      }   
    }
    
    
    for (i in 1:maxiter){
      
      Omega_prev = Omega
      for (k in 1:K){
        for (g in 1:G){ 
          Omega[[k,g]] = expand(R[[k]] + M[[k,g]] - (1/rho)*(n[g]*S[[k,g]] + Q[[k,g]]), rho, n[g])
        }
      }
      
      A = matrix(list(), K, 1)
      for (k in 1:K){
        A[[k]] = matrix(0, p, p)
        for (g in 1:G){
          A[[k]] = A[[k]] + (Omega[[k,g]] - M[[k,g]] + Q[[k,g]]/rho)
        }
        A[[k]] = A[[k]]/G
      }
      R = group_lasso(A, lambda*alpha/rho, penalize.diagonal) 
      
      
      
      for (g in 1:G){ 
        B = matrix(list(), K, 1)
        for (k in 1:K){
          B[[k]] = Omega[[k,g]] - R[[k]] + Q[[k,g]]/rho
        }
        M[,g] = group_lasso(B, lambda*(1-alpha)/rho, penalize.diagonal)        
      }
      
      
      for (k in 1:K){
        for (g in 1:G){ 
          Q[[k,g]] =  Q[[k,g]] + rho*(Omega[[k,g]] - (R[[k]] + M[[k,g]]))
        }
      }
      
      diff_value_1 = 0
      diff_value_2 = 0
      norm_value = 0
      for(k in 1:K){
        for (g in 1:G){ 
          diff_value_1 = diff_value_1 + sum(abs(Omega[[k,g]] - Omega_prev[[k,g]]))
          diff_value_2 = diff_value_2 + sum(abs(Omega[[k,g]] - (R[[k]] + M[[k,g]])))
          norm_value  = norm_value + sum(abs(Omega[[k,g]])) 
        }
      }   
      if (max(diff_value_1, diff_value_2) <= norm_value*epsilon){
        break
      }
      
      rho = min(rho*rho.incr,rho.max)
      
      
    }
    
    for(k in 1:K){
      for(g in 1:G){
        Omega[[k,g]] = R[[k]] + M[[k,g]]
      }
    }
    
    out = list(Omega.hat = Omega, R.hat = R, M.hat = M)
  }

