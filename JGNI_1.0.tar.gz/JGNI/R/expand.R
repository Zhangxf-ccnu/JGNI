expand = function(A, rho, n){
  edecomp <- eigen(A)
  D <- edecomp$values
  U <- edecomp$vectors
  D2 <- 0.5*(D + sqrt(D^2 + 4*n/rho ))
  Omega <- U %*% diag(D2) %*% t(U)
  Omega
}

